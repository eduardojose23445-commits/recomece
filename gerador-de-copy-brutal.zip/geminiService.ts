
import { GoogleGenAI, Type } from "@google/genai";
import { SalesPageContent } from "./types";

const PROMPT_TEMPLATE = `
Crie uma página de vendas em estilo "NOTÍCIA URGENTE" (Breaking News), cirúrgica, objetiva e de alto impacto emocional. 
O foco é uma revelação direta para pessoas travadas por procrastinação crônica e bloqueio emocional.

REGRAS DE OURO:
1. OBJETIVIDADE: Sem textos longos e cansativos. Frases curtas, diretas, que batem no ponto da dor e trazem alívio imediato.
2. OFERTA ALTERNATIVA (BOA): O segundo produto NÃO deve parecer "pobre" ou "incompleto". Ele deve ser um "Protocolo de Choque" focado exclusivamente no primeiro passo — um produto de alta qualidade para quem quer testar o método com baixo risco.
3. TOM: Noticiário sério, factual, removendo a culpa e focando na mecânica do cérebro travado.

Estrutura obrigatória em JSON:
1. headline: Manchete impactante. Curta. Remove a ideia de "preguiça".
2. opening: O "Lead" da notícia. 2-3 parágrafos curtos descrevendo a paralisia do cursor parado.
3. beliefBreak: A verdade científica/emocional: "Não é falta de vontade, é o limiar de dor do início".
4. solution: Apresentação objetiva do método como a solução liberada.
5. mainOffer: { name: "Execução Mesmo com Medo", price: "R$ 47,90", pos: "Sistema completo para dominar o ciclo do início ao fim", content: ["Protocolo Anti-Inércia", "Manual de Manutenção de Fluxo", "Acesso Vitalício"] }
6. altOffer: { name: "O Protocolo de Choque", price: "R$ 27,90", pos: "Foco total e absoluto no primeiro passo imediato", content: ["Ferramenta de Desbloqueio Instantâneo", "Áudio de Foco Profundo"] }
7. comparison: Explicação objetiva: Uma resolve o dia, a outra resolve a vida.
8. objections: FAQ estilo "Fatos vs Mitos".
9. ctaFinal: O custo emocional de não agir agora.

Mantenha o tom empático mas firme. Zero enrolação.
`;

export const generateSalesPage = async (context: string): Promise<SalesPageContent> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `${PROMPT_TEMPLATE}\n\nContexto específico do usuário: ${context}`,
    config: {
      temperature: 0.7,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          headline: { type: Type.STRING },
          opening: { type: Type.STRING },
          beliefBreak: { type: Type.STRING },
          solution: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              description: { type: Type.STRING }
            },
            required: ["title", "description"]
          },
          mainOffer: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              price: { type: Type.STRING },
              pos: { type: Type.STRING },
              content: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["name", "price", "pos", "content"]
          },
          altOffer: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              price: { type: Type.STRING },
              pos: { type: Type.STRING },
              content: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["name", "price", "pos", "content"]
          },
          comparison: { type: Type.STRING },
          objections: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                answer: { type: Type.STRING }
              },
              required: ["question", "answer"]
            }
          },
          ctaFinal: { type: Type.STRING }
        },
        required: ["headline", "opening", "beliefBreak", "solution", "mainOffer", "altOffer", "comparison", "objections", "ctaFinal"]
      }
    }
  });

  if (!response.text) {
    throw new Error("Falha ao gerar conteúdo.");
  }

  return JSON.parse(response.text) as SalesPageContent;
};
