
import React from 'react';
import { SalesPageContent } from '../types';

interface SalesPageProps {
  content: SalesPageContent;
}

const SalesPage: React.FC<SalesPageProps> = ({ content }) => {
  const currentDate = new Date().toLocaleDateString('pt-BR', {
    day: '2-digit',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div className="bg-[#050505] text-white min-h-screen">
      {/* Breaking News Hero Container */}
      <div className="relative overflow-hidden border-b border-zinc-900">
        <div className="absolute top-4 left-4 z-20 flex items-center gap-2">
          <div className="flex items-center gap-1.5 bg-red-600 px-3 py-1 rounded-sm animate-pulse shadow-lg shadow-red-600/20">
            <span className="block w-2 h-2 bg-white rounded-full"></span>
            <span className="text-[10px] font-black uppercase tracking-widest text-white">Ao Vivo</span>
          </div>
          <div className="bg-zinc-900/80 backdrop-blur px-3 py-1 border border-zinc-800 rounded-sm">
            <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">{currentDate}</span>
          </div>
        </div>

        <div className="absolute inset-0 pointer-events-none z-10 opacity-10 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]"></div>

        <div className="max-w-6xl mx-auto px-6 pt-24 pb-20 relative">
          <div className="max-w-4xl space-y-8">
            <div className="inline-block bg-white text-black px-3 py-0.5 text-[10px] font-black uppercase tracking-widest">
              Fato Confirmado
            </div>
            
            <h1 className="text-5xl md:text-8xl font-serif leading-[1.05] text-white italic tracking-tighter drop-shadow-2xl">
              {content.headline}
            </h1>
            
            <div className="flex items-center gap-4 border-l-4 border-red-600 pl-8">
              <p className="text-xl md:text-2xl text-zinc-400 font-medium leading-relaxed max-w-2xl">
                {content.opening.split('\n')[0]}
              </p>
            </div>
          </div>
        </div>

        {/* Breaking Ticker */}
        <div className="bg-red-700 w-full py-2.5 flex overflow-hidden whitespace-nowrap border-y border-red-600 relative z-20">
          <div className="flex animate-[ticker_25s_linear_infinite] shrink-0">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="flex items-center mx-12">
                <span className="text-white font-black text-xs uppercase tracking-[0.2em]">Breaking News:</span>
                <span className="text-red-100 text-xs font-bold ml-2">A inércia não é opcional, mas o seu desbloqueio agora é.</span>
                <span className="text-white/30 ml-12">•</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes ticker {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}</style>

      {/* Content Sections */}
      <div className="max-w-3xl mx-auto px-6 py-20 space-y-24">
        
        {/* Full Lead Text - Objective */}
        <section className="space-y-6 text-zinc-300 leading-relaxed text-lg border-b border-zinc-900 pb-20">
          {content.opening.split('\n').slice(1).map((para, i) => (
            <p key={i}>{para}</p>
          ))}
        </section>

        {/* Belief Break - News Insight */}
        <section className="bg-zinc-900/40 p-10 border border-zinc-800 rounded-lg">
          <h4 className="text-red-500 font-black text-[10px] uppercase tracking-[0.3em] mb-6">A Causa Raiz</h4>
          <p className="text-2xl md:text-3xl text-zinc-100 font-serif leading-tight italic">
            {content.beliefBreak}
          </p>
        </section>

        {/* Solution Presentation */}
        <section className="text-center space-y-6">
          <h2 className="text-3xl font-black text-white uppercase tracking-tighter">{content.solution.title}</h2>
          <p className="text-zinc-500 text-xl leading-relaxed max-w-xl mx-auto">
            {content.solution.description}
          </p>
        </section>

        {/* Offers - High End Comparison */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-12">
          {/* Main Offer - Masterclass UI */}
          <div className="bg-white text-black flex flex-col p-10 rounded-sm relative border-t-8 border-red-600 shadow-[10px_10px_0px_rgba(255,255,255,0.05)]">
            <span className="absolute -top-4 right-6 bg-red-600 text-white text-[9px] font-black uppercase px-3 py-1 tracking-widest">Recomendado</span>
            <h3 className="text-3xl font-black mb-1 uppercase tracking-tighter">{content.mainOffer.name}</h3>
            <p className="text-[10px] font-bold text-zinc-400 mb-8 uppercase tracking-widest">{content.mainOffer.pos}</p>
            <div className="text-5xl font-black mb-10 tracking-tighter">{content.mainOffer.price}</div>
            
            <ul className="space-y-4 mb-12 flex-grow">
              {content.mainOffer.content.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="text-red-600 font-black mt-0.5">✓</span>
                  <span className="text-xs font-bold uppercase tracking-tight">{item}</span>
                </li>
              ))}
            </ul>
            
            <button className="w-full bg-black text-white font-black py-5 px-6 hover:bg-zinc-800 transition-all uppercase tracking-[0.2em] text-[10px]">
              Resolver o Ciclo
            </button>
          </div>

          {/* Alt Offer - Specialized Tool UI */}
          <div className="bg-zinc-900 text-white flex flex-col p-10 border border-zinc-800 rounded-sm shadow-[10px_10px_0px_rgba(0,0,0,0.3)]">
            <h3 className="text-3xl font-black mb-1 uppercase tracking-tighter">{content.altOffer.name}</h3>
            <p className="text-[10px] text-zinc-500 mb-8 font-bold uppercase tracking-widest">{content.altOffer.pos}</p>
            <div className="text-5xl font-black mb-10 tracking-tighter">{content.altOffer.price}</div>
            
            <ul className="space-y-4 mb-12 flex-grow">
              {content.altOffer.content.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <span className="text-zinc-600 font-black mt-0.5">•</span>
                  <span className="text-xs font-bold uppercase tracking-tight text-zinc-400">{item}</span>
                </li>
              ))}
            </ul>
            
            <button className="w-full border-2 border-zinc-700 text-white font-black py-5 px-6 hover:bg-zinc-800 transition-all text-[10px] uppercase tracking-[0.2em]">
              Resolver o Início
            </button>
          </div>
        </section>

        {/* Comparison Section - Brief */}
        <div className="text-center py-4 text-zinc-600 text-[10px] font-black uppercase tracking-[0.3em]">
          {content.comparison}
        </div>

        {/* Objections - Fact Check Objective */}
        <section className="space-y-12">
          <div className="text-center">
            <h3 className="text-xs font-black text-zinc-500 uppercase tracking-[0.4em]">Fact Check</h3>
          </div>
          <div className="space-y-8">
            {content.objections.map((obj, i) => (
              <div key={i} className="grid md:grid-cols-3 gap-4 border-t border-zinc-900 pt-6">
                <div className="md:col-span-1 text-red-700 font-black text-xs uppercase italic tracking-widest">Questão {i+1}</div>
                <div className="md:col-span-2 space-y-2">
                  <h4 className="text-lg font-bold text-zinc-100">“{obj.question}”</h4>
                  <p className="text-zinc-500 text-sm leading-relaxed">{obj.answer}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CTA Final */}
        <footer className="text-center space-y-12 py-20 border-t border-zinc-900">
          <p className="text-zinc-200 text-2xl font-serif font-bold italic max-w-xl mx-auto leading-tight">
            {content.ctaFinal}
          </p>
          
          <div className="space-y-6">
            <button className="bg-red-600 text-white font-black py-8 px-20 rounded-sm hover:bg-red-500 transition-all transform hover:scale-105 active:scale-95 shadow-2xl shadow-red-900/20 uppercase tracking-[0.3em] text-[11px]">
              Assumir Controle Agora
            </button>
            <div className="text-[9px] font-black uppercase tracking-[0.3em] text-zinc-700">
              Protocolo Criptografado • Acesso Imediato • Sem Perguntas
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default SalesPage;
