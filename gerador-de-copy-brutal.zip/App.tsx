
import React, { useState } from 'react';
import { generateSalesPage } from './geminiService';
import { SalesPageContent, AppState } from './types';
import SalesPage from './components/SalesPage';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>(AppState.IDLE);
  const [context, setContext] = useState('');
  const [content, setContent] = useState<SalesPageContent | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (state === AppState.LOADING) return;
    
    setState(AppState.LOADING);
    setError(null);
    
    try {
      const generatedContent = await generateSalesPage(context || 'Geral (Trabalho/Estudos)');
      setContent(generatedContent);
      setState(AppState.RESULTS);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Ocorreu um erro ao gerar a copy. Tente novamente.');
      setState(AppState.ERROR);
    }
  };

  const copyToClipboard = () => {
    if (!content) return;
    const text = JSON.stringify(content, null, 2);
    navigator.clipboard.writeText(text);
    alert('JSON da Copy copiado para a área de transferência!');
  };

  return (
    <div className="min-h-screen bg-[#020202] selection:bg-red-600 selection:text-white">
      {/* Background Grid/Effect */}
      <div className="fixed inset-0 pointer-events-none opacity-20 bg-[linear-gradient(to_right,#121212_1px,transparent_1px),linear-gradient(to_bottom,#121212_1px,transparent_1px)] bg-[size:40px_40px]"></div>
      
      {state === AppState.IDLE || state === AppState.ERROR ? (
        <div className="relative max-w-5xl mx-auto px-6 pt-24 pb-20 space-y-16">
          {/* Header Badge */}
          <div className="flex justify-center">
            <div className="bg-red-600 px-4 py-1.5 rounded-sm shadow-lg shadow-red-900/20">
              <span className="text-[10px] font-black text-white uppercase tracking-[0.4em]">Intelligence Bureau v2.5</span>
            </div>
          </div>

          <div className="text-center space-y-6">
            <h1 className="text-6xl md:text-9xl font-black tracking-tighter text-white leading-none">
              COPY<span className="text-red-600 italic font-serif">BRUTAL</span>
            </h1>
            <p className="text-zinc-500 text-xl md:text-2xl max-w-3xl mx-auto font-medium leading-relaxed uppercase tracking-tighter italic">
              A REVELAÇÃO QUE O SEU PÚBLICO NÃO CONSEGUE IGNORAR.
            </p>
          </div>

          <div className="max-w-2xl mx-auto bg-zinc-900/40 backdrop-blur-md p-8 rounded-sm border border-zinc-800 shadow-2xl space-y-8 relative overflow-hidden group">
            {/* Input Overlay decoration */}
            <div className="absolute top-0 right-0 p-4 opacity-10">
              <div className="w-24 h-24 border-t-2 border-r-2 border-white"></div>
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block">Defina o Contexto da Emergência</label>
              <textarea
                placeholder="Ex: Estudantes de medicina travados no TCC, Escritores com bloqueio criativo, Empreendedores com medo de lançar..."
                className="w-full bg-black border border-zinc-800 p-6 rounded-sm text-white placeholder:text-zinc-800 focus:outline-none focus:border-red-600 focus:ring-1 focus:ring-red-600 transition-all h-40 font-mono text-sm leading-relaxed"
                value={context}
                onChange={(e) => setContext(e.target.value)}
              />
            </div>

            <button
              onClick={handleGenerate}
              className="w-full bg-red-600 text-white font-black py-6 px-8 rounded-sm hover:bg-red-700 transition-all active:scale-[0.98] shadow-xl shadow-red-900/10 uppercase tracking-[0.2em] text-xs"
            >
              Iniciar Transmissão de Copy
            </button>

            {state === AppState.ERROR && (
              <div className="text-red-500 text-xs font-bold bg-red-950/30 p-4 rounded-sm border border-red-900/50 uppercase tracking-widest text-center">
                ALERTA DE SISTEMA: {error}
              </div>
            )}
          </div>

          {/* Footer stats style */}
          <div className="flex flex-wrap justify-center gap-12 pt-10 border-t border-zinc-900/50 opacity-30 grayscale">
             <div className="text-center">
                <div className="text-3xl font-black text-white">0%</div>
                <div className="text-[10px] font-bold text-zinc-500 uppercase">MOTIVAÇÃO CLICHÊ</div>
             </div>
             <div className="text-center">
                <div className="text-3xl font-black text-white">100%</div>
                <div className="text-[10px] font-bold text-zinc-500 uppercase">IMPACTO BRUTAL</div>
             </div>
             <div className="text-center">
                <div className="text-3xl font-black text-white">X2</div>
                <div className="text-[10px] font-bold text-zinc-500 uppercase">PODER DE CONVERSÃO</div>
             </div>
          </div>
        </div>
      ) : state === AppState.LOADING ? (
        <div className="min-h-screen flex flex-col items-center justify-center p-6 space-y-12 bg-black overflow-hidden">
          {/* Central Eye/Scanner effect */}
          <div className="relative">
            <div className="w-24 h-24 border-4 border-red-600 border-t-transparent rounded-full animate-spin"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-2 h-2 bg-red-600 rounded-full animate-ping"></div>
            </div>
          </div>
          
          <div className="text-center space-y-4">
            <h2 className="text-4xl font-black text-white uppercase tracking-[0.3em] italic">Analisando Bloqueios...</h2>
            <div className="space-y-1">
              <p className="text-red-500 font-mono text-xs animate-pulse">DETECTANDO PARALISIA EMOCIONAL...</p>
              <p className="text-zinc-600 font-mono text-xs uppercase">Sincronizando frequências de urgência</p>
            </div>
          </div>
          
          {/* Animated Matrix-like text for flavor */}
          <div className="text-[10px] font-mono text-zinc-800 opacity-20 text-center max-w-md uppercase overflow-hidden h-20 leading-none">
            {Array.from({length: 10}).map((_, i) => (
              <div key={i} className="whitespace-nowrap">
                {Math.random().toString(36).substring(2, 15)} PROCESS_BLOCKAGE_REMOVAL_INITIATED {Math.random().toString(36).substring(2, 15)}
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="relative pt-2">
          {/* News Action Bar */}
          <div className="sticky top-0 z-[100] bg-black/90 backdrop-blur-xl border-b border-zinc-800 p-3">
            <div className="max-w-6xl mx-auto flex justify-between items-center px-4">
              <button 
                onClick={() => setState(AppState.IDLE)}
                className="text-zinc-500 hover:text-white transition-colors text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2"
              >
                <span className="text-red-600">«</span> Nova Pauta
              </button>
              
              <div className="flex gap-3">
                <button 
                  onClick={copyToClipboard}
                  className="bg-zinc-900 border border-zinc-800 hover:border-zinc-600 text-white px-5 py-2 rounded-sm text-[10px] font-black uppercase tracking-widest transition-all"
                >
                  Exportar Dados
                </button>
                <button 
                   onClick={() => window.print()}
                   className="bg-red-700 hover:bg-red-600 text-white px-5 py-2 rounded-sm text-[10px] font-black uppercase tracking-widest transition-all shadow-lg shadow-red-900/20"
                >
                  Imprimir Dossiê
                </button>
              </div>
            </div>
          </div>

          <SalesPage content={content!} />
        </div>
      )}
    </div>
  );
};

export default App;
