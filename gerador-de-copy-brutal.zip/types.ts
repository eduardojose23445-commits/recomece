
export interface SalesPageContent {
  headline: string;
  opening: string;
  beliefBreak: string;
  solution: {
    title: string;
    description: string;
  };
  mainOffer: {
    name: string;
    price: string;
    pos: string;
    content: string[];
  };
  altOffer: {
    name: string;
    price: string;
    pos: string;
    content: string[];
  };
  comparison: string;
  objections: { question: string; answer: string }[];
  ctaFinal: string;
}

export enum AppState {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  RESULTS = 'RESULTS',
  ERROR = 'ERROR'
}
